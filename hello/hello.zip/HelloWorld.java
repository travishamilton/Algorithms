/* *****************************************************************************
 *  Name:              Travis Hamilton
 *  Last modified:     January 10, 2023
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
